"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImageSourceStrategy = void 0;
var ImageSourceStrategy;
(function (ImageSourceStrategy) {
    ImageSourceStrategy["Hybrid"] = "hybrid";
    ImageSourceStrategy["External"] = "external";
    ImageSourceStrategy["Internal"] = "internal";
})(ImageSourceStrategy || (exports.ImageSourceStrategy = ImageSourceStrategy = {}));
//# sourceMappingURL=Config.js.map